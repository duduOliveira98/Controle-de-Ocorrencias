package br.com.progvisual2.sdkgooglemaps.activity;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

import br.com.progvisual2.sdkgooglemaps.R;
import br.com.progvisual2.sdkgooglemaps.helper.UsuarioFirebase;
import br.com.progvisual2.sdkgooglemaps.model.Cadastra_Usuario;

public class Menu extends AppCompatActivity {

    ImageButton btocorrenciasMap, btcadastraOc, btmapa;

    TextView txnome;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu);

        btocorrenciasMap = findViewById(R.id.ocorrenciaMap);
        btcadastraOc = findViewById(R.id.cadastraOcorrencia);
      //  txnome = findViewById(R.id.nomeUser);
        btmapa = findViewById(R.id.mapa);

//        usuario();


        //---------------------AREA DESTINADA PARA METODOS DE BOTAO-----------------------
        btocorrenciasMap.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                consultaOcorrenciasMaps(view);
            }
        });

        btcadastraOc.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                cadastraOcorrenciaMaps(view);

            }
        });

        btmapa.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                AcessoeMaps(view);
            }
        });
    }

    public void AcessoeMaps(View view){

        Intent intent = new Intent(this, MapsActivity.class);
        startActivity(intent);

    }

    public void usuario(){

        Cadastra_Usuario cad = UsuarioFirebase.getDadosUsuarioLogado();
       String nome = cad.getNome();

       Cadastra_Usuario use = UsuarioFirebase.getDadosUsuarioLogado();
       use.getLogin();
      //  txnome.setText( use.getLogin());

        FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
        if (user != null) {
            // Name, email address, and profile photo Url
            String name = user.getDisplayName();
            String email = user.getEmail();
            // Check if user's email is verified
            boolean emailVerified = user.isEmailVerified();
            // The user's ID, unique to the Firebase project. Do NOT use this value to
            // authenticate with your backend server, if you have one. Use
            // FirebaseUser.getIdToken() instead.
           // String uid = user.getUid();
         //   txnome.setText(name.toUpperCase());
        }


    }

    public void consultaOcorrenciasMaps(View view){
        Intent intent = new Intent(this, ListaOcorrencia.class);
        startActivity(intent);

    }

    public void cadastraOcorrenciaMaps(View view){

        Intent intentOcorrencia = new Intent(this, MapsOcorrencia.class);
        startActivity(intentOcorrencia);

    }


}
